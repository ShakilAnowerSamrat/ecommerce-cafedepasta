<form class="form-horizontal" action="{{ route('payment_method.update') }}" method="POST">
    @csrf
    <input type="hidden" name="payment_method" value="uddoktapay">
    <div class="form-group row">
        <input type="hidden" name="types[]" value="UDDOKTAPAY_API_KEY">
        <div class="col-md-4">
            <label class="col-from-label">{{ translate('UddoktaPay Api Key') }}</label>
        </div>
        <div class="col-md-8">
            <input type="text" class="form-control" name="UDDOKTAPAY_API_KEY" value="{{ env('UDDOKTAPAY_API_KEY') }}"
                placeholder="{{ translate('UddoktaPay Api Key') }}" required>
        </div>
    </div>
    <div class="form-group row">
        <input type="hidden" name="types[]" value="UDDOKTAPAY_API_URL">
        <div class="col-md-4">
            <label class="col-from-label">{{ translate('UddoktaPay Api Url') }}</label>
        </div>
        <div class="col-md-8">
            <input type="text" class="form-control" name="UDDOKTAPAY_API_URL" value="{{ env('UDDOKTAPAY_API_URL') }}"
                placeholder="{{ translate('UddoktaPay Api Url') }}" required>
        </div>
    </div>
    <div class="form-group mb-0 text-right">
        <button type="submit" class="btn btn-sm btn-primary">{{ translate('Save') }}</button>
    </div>
</form>